# Ship It Button

This file contains the code that retrieve's the latest release, creates a new release, then creates a deployment. 

## Details 

- Desgined as a serverless function w/ AWS Lambda 
- Runtime is Node.js 6.10


